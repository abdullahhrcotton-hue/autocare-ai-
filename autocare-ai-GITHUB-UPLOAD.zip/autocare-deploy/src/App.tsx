import React, { useState, createContext, useContext } from 'react';
import Dashboard from './screens/Dashboard';
import FuelHistory from './screens/FuelHistory';
import OilChange from './screens/OilChange';
import RPMMeter from './screens/RPMMeter';
import Analytics from './screens/Analytics';
import Vehicles from './screens/Vehicles';
import BottomNav from './components/BottomNav';
import SplashScreen from './components/SplashScreen';
import './App.css';

export const ThemeContext = createContext<{ dark: boolean; toggle: () => void }>({ dark: true, toggle: () => {} });
export const useTheme = () => useContext(ThemeContext);
export type Screen = 'dashboard' | 'fuel' | 'oil' | 'rpm' | 'analytics' | 'vehicles';

export interface Vehicle {
  id: string; name: string; model: string; year: number;
  regNumber: string; fuelType: string; engineCC: number;
  type: 'car' | 'bike' | 'van' | 'truck'; odometer: number; color: string;
}
export interface FuelEntry {
  id: string; vehicleId: string; date: string; liters: number;
  totalCost: number; pricePerLiter: number; odometer: number;
  station: string; mileage?: number;
}
export interface OilRecord {
  id: string; vehicleId: string; date: string; oilType: string;
  brand: string; grade: string; kmAtChange: number; workshop: string;
  cost: number; intervalKm: number; nextDueKm: number;
}

export const AppContext = createContext<{
  screen: Screen; setScreen: (s: Screen) => void;
  vehicles: Vehicle[]; setVehicles: (v: Vehicle[]) => void;
  activeVehicle: number; setActiveVehicle: (i: number) => void;
  fuelEntries: FuelEntry[]; setFuelEntries: (e: FuelEntry[]) => void;
  oilRecords: OilRecord[]; setOilRecords: (r: OilRecord[]) => void;
}>({} as any);

const defaultVehicles: Vehicle[] = [
  { id:'1', name:'My Sedan', model:'Civic 1.5T', year:2023, regNumber:'KHI-1234', fuelType:'Petrol', engineCC:1500, type:'car', odometer:24850, color:'#60a5fa' },
  { id:'2', name:'Work Van', model:'Transit 2.0', year:2021, regNumber:'KHI-5678', fuelType:'Diesel', engineCC:2000, type:'van', odometer:61200, color:'#a78bfa' },
];
const defaultFuel: FuelEntry[] = [
  { id:'1', vehicleId:'1', date:'2025-05-01', liters:45, totalCost:6750, pricePerLiter:150, odometer:24200, station:'Shell Clifton', mileage:14.2 },
  { id:'2', vehicleId:'1', date:'2025-04-18', liters:42, totalCost:6300, pricePerLiter:150, odometer:23600, station:'PSO Defence', mileage:13.8 },
  { id:'3', vehicleId:'1', date:'2025-04-02', liters:48, totalCost:7200, pricePerLiter:150, odometer:23000, station:'Total Parco', mileage:14.5 },
  { id:'4', vehicleId:'2', date:'2025-05-05', liters:60, totalCost:9600, pricePerLiter:160, odometer:61000, station:'Attock DHA', mileage:12.1 },
];
const defaultOil: OilRecord[] = [
  { id:'1', vehicleId:'1', date:'2025-03-15', oilType:'Synthetic', brand:'Mobil 1', grade:'5W-30', kmAtChange:22000, workshop:'AutoPro Service', cost:8500, intervalKm:5000, nextDueKm:27000 },
  { id:'2', vehicleId:'2', date:'2025-02-10', oilType:'Semi-Synthetic', brand:'Castrol GTX', grade:'10W-40', kmAtChange:58000, workshop:'Ford Workshop', cost:6200, intervalKm:3000, nextDueKm:61000 },
];

function App() {
  const [splash, setSplash] = useState(true);
  const [dark, setDark] = useState(true);
  const [screen, setScreen] = useState<Screen>('dashboard');
  const [vehicles, setVehicles] = useState<Vehicle[]>(defaultVehicles);
  const [activeVehicle, setActiveVehicle] = useState(0);
  const [fuelEntries, setFuelEntries] = useState<FuelEntry[]>(defaultFuel);
  const [oilRecords, setOilRecords] = useState<OilRecord[]>(defaultOil);

  if (splash) return <SplashScreen onDone={() => setSplash(false)} />;

  const screens: Record<Screen, React.ReactNode> = {
    dashboard: <Dashboard />, fuel: <FuelHistory />, oil: <OilChange />,
    rpm: <RPMMeter />, analytics: <Analytics />, vehicles: <Vehicles />,
  };

  return (
    <ThemeContext.Provider value={{ dark, toggle: () => setDark(d => !d) }}>
      <AppContext.Provider value={{ screen, setScreen, vehicles, setVehicles, activeVehicle, setActiveVehicle, fuelEntries, setFuelEntries, oilRecords, setOilRecords }}>
        <div className={`app-root ${dark ? 'dark' : 'light'}`}>
          <div className="mobile-frame">
            <div className="screen-content">{screens[screen]}</div>
            <BottomNav />
          </div>
        </div>
      </AppContext.Provider>
    </ThemeContext.Provider>
  );
}
export default App;
