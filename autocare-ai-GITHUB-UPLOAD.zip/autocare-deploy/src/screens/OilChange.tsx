import React, { useContext, useState } from 'react';
import { AppContext, OilRecord } from '../App';

function OilModal({ onClose, onSave, vehicleId, currentOdo }: { onClose:()=>void; onSave:(r:OilRecord)=>void; vehicleId:string; currentOdo:number }) {
  const [form, setForm] = useState({
    date: new Date().toISOString().split('T')[0], oilType:'Synthetic', brand:'', grade:'5W-30',
    kmAtChange: String(currentOdo), workshop:'', cost:'', intervalKm:'5000'
  });
  const set = (k:string,v:string) => setForm(f=>({...f,[k]:v}));
  const nextDue = (parseFloat(form.kmAtChange)||0) + (parseFloat(form.intervalKm)||5000);
  const save = () => {
    if (!form.brand || !form.cost) return;
    onSave({ id:Date.now().toString(), vehicleId, date:form.date, oilType:form.oilType, brand:form.brand,
      grade:form.grade, kmAtChange:parseFloat(form.kmAtChange), workshop:form.workshop||'Unknown',
      cost:parseFloat(form.cost), intervalKm:parseFloat(form.intervalKm), nextDueKm:nextDue });
    onClose();
  };
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-sheet" onClick={e=>e.stopPropagation()}>
        <div className="modal-handle"/>
        <div style={{ fontFamily:"'Rajdhani',sans-serif", fontSize:22, fontWeight:700, color:'var(--text-primary)', marginBottom:20 }}>
          Log Oil Change
        </div>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
          <div className="form-group" style={{gridColumn:'1/-1'}}>
            <label className="form-label">Date</label>
            <input className="form-input" type="date" value={form.date} onChange={e=>set('date',e.target.value)}/>
          </div>
          <div className="form-group">
            <label className="form-label">Oil Type</label>
            <select className="form-input" value={form.oilType} onChange={e=>set('oilType',e.target.value)}>
              {['Synthetic','Semi-Synthetic','Mineral','Full Synthetic'].map(o=><option key={o}>{o}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Oil Grade</label>
            <select className="form-input" value={form.grade} onChange={e=>set('grade',e.target.value)}>
              {['5W-30','5W-40','10W-30','10W-40','0W-20','15W-40'].map(g=><option key={g}>{g}</option>)}
            </select>
          </div>
          <div className="form-group" style={{gridColumn:'1/-1'}}>
            <label className="form-label">Brand</label>
            <input className="form-input" type="text" placeholder="Mobil 1, Castrol..." value={form.brand} onChange={e=>set('brand',e.target.value)}/>
          </div>
          <div className="form-group">
            <label className="form-label">KM at Change</label>
            <input className="form-input" type="number" value={form.kmAtChange} onChange={e=>set('kmAtChange',e.target.value)}/>
          </div>
          <div className="form-group">
            <label className="form-label">Interval (KM)</label>
            <select className="form-input" value={form.intervalKm} onChange={e=>set('intervalKm',e.target.value)}>
              {['3000','5000','7500','10000','15000'].map(i=><option key={i}>{i}</option>)}
            </select>
          </div>
          <div className="form-group" style={{gridColumn:'1/-1'}}>
            <label className="form-label">Next Due KM (auto)</label>
            <div className="form-input" style={{ color:'var(--success)', fontWeight:600 }}>
              {nextDue.toLocaleString()} km
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Cost (₨)</label>
            <input className="form-input" type="number" placeholder="8500" value={form.cost} onChange={e=>set('cost',e.target.value)}/>
          </div>
          <div className="form-group">
            <label className="form-label">Workshop</label>
            <input className="form-input" type="text" placeholder="AutoPro Service" value={form.workshop} onChange={e=>set('workshop',e.target.value)}/>
          </div>
        </div>
        <div style={{ display:'flex', gap:10, marginTop:8 }}>
          <button className="btn-ghost" style={{flex:1}} onClick={onClose}>Cancel</button>
          <button className="btn-primary" style={{flex:2}} onClick={save}>Save Record</button>
        </div>
      </div>
    </div>
  );
}

function OilHealthBar({ pct, remaining }: { pct:number; remaining:number }) {
  const color = pct>50?'#10b981':pct>20?'#f59e0b':'#ef4444';
  const [width, setWidth] = React.useState(0);
  React.useEffect(() => { setTimeout(() => setWidth(pct), 200); }, [pct]);
  return (
    <div>
      <div style={{ display:'flex', justifyContent:'space-between', marginBottom:8 }}>
        <span style={{ fontSize:12, color:'var(--text-secondary)' }}>Oil Life Remaining</span>
        <span style={{ fontSize:12, fontWeight:600, color }}>
          {remaining > 0 ? `${remaining.toLocaleString()} km` : 'OVERDUE'}
        </span>
      </div>
      <div style={{ height:8, background:'var(--border)', borderRadius:4, overflow:'hidden' }}>
        <div style={{ height:'100%', width:`${width}%`, background:color, borderRadius:4,
          transition:'width 1.2s cubic-bezier(0.4,0,0.2,1)' }}/>
      </div>
      <div style={{ display:'flex', justifyContent:'space-between', marginTop:4 }}>
        <span style={{ fontSize:10, color:'var(--text-muted)' }}>0 km</span>
        <span style={{ fontSize:10, color:'var(--text-muted)' }}>Full interval</span>
      </div>
    </div>
  );
}

export default function OilChange() {
  const { vehicles, activeVehicle, oilRecords, setOilRecords } = useContext(AppContext);
  const v = vehicles[activeVehicle];
  const records = oilRecords.filter(o=>o.vehicleId===v.id).sort((a,b)=>b.date.localeCompare(a.date));
  const [showModal, setShowModal] = useState(false);
  const lastOil = records[0];
  const remaining = lastOil ? lastOil.nextDueKm - v.odometer : 0;
  const pct = lastOil ? Math.max(0,Math.min(100,(remaining/lastOil.intervalKm)*100)) : 100;

  const addRecord = (r: OilRecord) => setOilRecords([...oilRecords, r]);

  return (
    <div>
      <div className="screen-header">
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <div>
            <div className="screen-title">Oil Management</div>
            <div className="screen-subtitle">{v.name} · {records.length} records</div>
          </div>
          <button className="btn-primary" style={{borderRadius:12}} onClick={()=>setShowModal(true)}>
            <span style={{fontSize:18,lineHeight:1}}>+</span> Log
          </button>
        </div>
      </div>

      <div style={{padding:'16px'}}>
        {/* Status Card */}
        <div className="glass-card animate-in" style={{
          padding:20, marginBottom:16,
          background: remaining < 0 ? 'rgba(239,68,68,0.08)' : remaining < 500 ? 'rgba(245,158,11,0.08)' : 'rgba(16,185,129,0.08)',
          border: `1px solid ${remaining < 0 ? '#ef444430' : remaining < 500 ? '#f59e0b30' : '#10b98130'}`
        }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:16 }}>
            <div>
              <div style={{ fontSize:12, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:.5, marginBottom:4 }}>
                Oil Change Status
              </div>
              {lastOil ? (
                <>
                  <div style={{ fontFamily:"'Rajdhani',sans-serif", fontSize:28, fontWeight:700,
                    color: remaining < 0 ? 'var(--danger)' : remaining < 500 ? 'var(--warning)' : 'var(--success)' }}>
                    {remaining > 0 ? `${remaining.toLocaleString()} km` : 'Overdue!'}
                  </div>
                  <div style={{ fontSize:12, color:'var(--text-secondary)' }}>
                    until next oil change
                  </div>
                </>
              ) : (
                <div style={{ fontSize:16, color:'var(--text-secondary)' }}>No records yet</div>
              )}
            </div>
            <div style={{ fontSize:40 }}>{remaining < 0 ? '🔴' : remaining < 500 ? '⚠️' : '✅'}</div>
          </div>
          {lastOil && <OilHealthBar pct={pct} remaining={remaining}/>}
        </div>

        {/* Last Oil Details */}
        {lastOil && (
          <div className="glass-card animate-in delay-1" style={{padding:16, marginBottom:16}}>
            <div className="section-label" style={{marginBottom:12}}>Last Oil Change Details</div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
              {[
                ['Oil Brand', lastOil.brand],
                ['Oil Type', lastOil.oilType],
                ['Grade', lastOil.grade],
                ['Changed at', `${lastOil.kmAtChange.toLocaleString()} km`],
                ['Next due at', `${lastOil.nextDueKm.toLocaleString()} km`],
                ['Workshop', lastOil.workshop],
                ['Date', lastOil.date],
                ['Cost', `₨${lastOil.cost.toLocaleString()}`],
              ].map(([k,val]) => (
                <div key={k} style={{ padding:'10px 12px', background:'var(--bg-card)', borderRadius:10,
                  border:'1px solid var(--border)' }}>
                  <div style={{ fontSize:10, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:.5 }}>{k}</div>
                  <div style={{ fontSize:13, fontWeight:600, color:'var(--text-primary)', marginTop:2 }}>{val}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Reminders */}
        <div className="glass-card animate-in delay-2" style={{padding:16, marginBottom:16}}>
          <div className="section-label" style={{marginBottom:10}}>Smart Reminders</div>
          {[
            { label:'Oil change at ' + (lastOil ? (lastOil.nextDueKm).toLocaleString() : '—') + ' km', active: remaining < 500, type:'warning' },
            { label:'Service due next month', active: false, type:'info' },
            { label:'Tire rotation reminder', active: true, type:'info' },
          ].map((r,i) => (
            <div key={i} style={{ display:'flex', alignItems:'center', gap:10, padding:'10px 12px',
              background: r.active ? 'rgba(245,158,11,0.08)' : 'var(--bg-card)',
              border: `1px solid ${r.active ? '#f59e0b30' : 'var(--border)'}`,
              borderRadius:10, marginBottom:8 }}>
              <div style={{ width:8, height:8, borderRadius:'50%',
                background: r.active ? 'var(--warning)' : 'var(--text-muted)' }}/>
              <span style={{ fontSize:13, color: r.active ? 'var(--text-primary)' : 'var(--text-secondary)' }}>{r.label}</span>
              <div style={{ marginLeft:'auto' }}>
                <div style={{ width:36, height:20, borderRadius:10, cursor:'pointer',
                  background: r.active ? 'var(--accent)' : 'var(--border)',
                  display:'flex', alignItems:'center', padding:'0 3px',
                  justifyContent: r.active ? 'flex-end' : 'flex-start' }}>
                  <div style={{ width:14, height:14, borderRadius:'50%', background:'white' }}/>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* History */}
        <div className="section-label animate-in delay-3">Change History</div>
        {records.map((r,i) => (
          <div key={r.id} className="glass-card animate-in" style={{ padding:'14px 16px', marginBottom:10,
            animationDelay:`${0.05*i}s` }}>
            <div style={{ display:'flex', justifyContent:'space-between' }}>
              <div>
                <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:4 }}>
                  <span style={{ fontSize:16 }}>🔧</span>
                  <span style={{ fontSize:14, fontWeight:600, color:'var(--text-primary)' }}>{r.brand} {r.grade}</span>
                </div>
                <div style={{ fontSize:12, color:'var(--text-secondary)', marginBottom:6 }}>{r.date} · {r.workshop}</div>
                <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
                  <span className="badge badge-info">{r.oilType}</span>
                  <span className="badge badge-success">{r.kmAtChange.toLocaleString()} km</span>
                </div>
              </div>
              <div style={{ textAlign:'right' }}>
                <div style={{ fontFamily:"'Rajdhani',sans-serif", fontSize:18, fontWeight:700, color:'var(--success)' }}>
                  ₨{r.cost.toLocaleString()}
                </div>
                <div style={{ fontSize:11, color:'var(--text-muted)' }}>Next: {r.nextDueKm.toLocaleString()} km</div>
              </div>
            </div>
          </div>
        ))}

        {records.length === 0 && (
          <div style={{ textAlign:'center', padding:'40px 20px', color:'var(--text-muted)' }}>
            <div style={{ fontSize:40, marginBottom:12 }}>🔧</div>
            <div style={{ fontSize:14 }}>No oil change records</div>
          </div>
        )}
      </div>

      {showModal && <OilModal onClose={()=>setShowModal(false)} onSave={addRecord} vehicleId={v.id} currentOdo={v.odometer}/>}
    </div>
  );
}
