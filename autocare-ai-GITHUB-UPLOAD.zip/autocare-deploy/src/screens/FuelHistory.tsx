import React, { useContext, useState } from 'react';
import { AppContext, FuelEntry } from '../App';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

function FuelModal({ onClose, onSave, vehicleId }: { onClose:()=>void; onSave:(e:FuelEntry)=>void; vehicleId:string }) {
  const [form, setForm] = useState({ date:new Date().toISOString().split('T')[0], liters:'', totalCost:'', odometer:'', station:'' });
  const ppl = form.liters && form.totalCost ? (parseFloat(form.totalCost)/parseFloat(form.liters)).toFixed(1) : '—';
  const save = () => {
    if (!form.liters || !form.totalCost || !form.odometer) return;
    onSave({ id:Date.now().toString(), vehicleId, date:form.date, liters:parseFloat(form.liters),
      totalCost:parseFloat(form.totalCost), pricePerLiter:parseFloat(form.totalCost)/parseFloat(form.liters),
      odometer:parseFloat(form.odometer), station:form.station||'Unknown', mileage:undefined });
    onClose();
  };
  const set = (k:string, v:string) => setForm(f=>({...f,[k]:v}));
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-sheet" onClick={e=>e.stopPropagation()}>
        <div className="modal-handle"/>
        <div style={{ fontFamily:"'Rajdhani',sans-serif", fontSize:22, fontWeight:700, color:'var(--text-primary)', marginBottom:20 }}>
          Add Fuel Entry
        </div>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
          <div className="form-group" style={{ gridColumn:'1/-1' }}>
            <label className="form-label">Date</label>
            <input className="form-input" type="date" value={form.date} onChange={e=>set('date',e.target.value)}/>
          </div>
          <div className="form-group">
            <label className="form-label">Liters</label>
            <input className="form-input" type="number" placeholder="45.0" value={form.liters} onChange={e=>set('liters',e.target.value)}/>
          </div>
          <div className="form-group">
            <label className="form-label">Total Cost (₨)</label>
            <input className="form-input" type="number" placeholder="6750" value={form.totalCost} onChange={e=>set('totalCost',e.target.value)}/>
          </div>
          <div className="form-group" style={{ gridColumn:'1/-1' }}>
            <label className="form-label">Price / Liter</label>
            <div className="form-input" style={{ color:'var(--accent)', fontWeight:600 }}>₨ {ppl}</div>
          </div>
          <div className="form-group" style={{ gridColumn:'1/-1' }}>
            <label className="form-label">Odometer (KM)</label>
            <input className="form-input" type="number" placeholder="24850" value={form.odometer} onChange={e=>set('odometer',e.target.value)}/>
          </div>
          <div className="form-group" style={{ gridColumn:'1/-1' }}>
            <label className="form-label">Fuel Station</label>
            <input className="form-input" type="text" placeholder="Shell Clifton" value={form.station} onChange={e=>set('station',e.target.value)}/>
          </div>
        </div>
        <div style={{ display:'flex', gap:10, marginTop:8 }}>
          <button className="btn-ghost" style={{ flex:1 }} onClick={onClose}>Cancel</button>
          <button className="btn-primary" style={{ flex:2 }} onClick={save}>Save Entry</button>
        </div>
      </div>
    </div>
  );
}

export default function FuelHistory() {
  const { vehicles, activeVehicle, fuelEntries, setFuelEntries } = useContext(AppContext);
  const v = vehicles[activeVehicle];
  const entries = fuelEntries.filter(f=>f.vehicleId===v.id).sort((a,b)=>b.date.localeCompare(a.date));
  const [showModal, setShowModal] = useState(false);
  const [filter, setFilter] = useState('all');

  const totalSpent = entries.reduce((a,e)=>a+e.totalCost,0);
  const avgMileage = entries.filter(e=>e.mileage).reduce((a,e)=>a+(e.mileage||0),0)/(entries.filter(e=>e.mileage).length||1);
  const totalLiters = entries.reduce((a,e)=>a+e.liters,0);

  const chartData = [...entries].reverse().map((e,i) => ({
    name: e.date.slice(5), mileage: e.mileage||0, cost: Math.round(e.totalCost/1000*10)/10
  }));

  const addEntry = (e: FuelEntry) => setFuelEntries([...fuelEntries, e]);

  const CustomTooltip = ({ active, payload }: any) => {
    if (!active || !payload?.length) return null;
    return (
      <div style={{ background:'var(--bg-secondary)', border:'1px solid var(--border)', borderRadius:8, padding:'8px 12px', fontSize:12 }}>
        <div style={{ color:'var(--accent)' }}>{payload[0]?.value} km/L</div>
      </div>
    );
  };

  return (
    <div>
      <div className="screen-header">
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <div>
            <div className="screen-title">Fuel History</div>
            <div className="screen-subtitle">{v.name} · {entries.length} records</div>
          </div>
          <button className="btn-primary" style={{ borderRadius:12 }} onClick={()=>setShowModal(true)}>
            <span style={{ fontSize:18, lineHeight:1 }}>+</span> Add
          </button>
        </div>
      </div>

      <div style={{ padding:'16px' }}>
        {/* Summary */}
        <div className="metric-row animate-in" style={{ marginBottom:16 }}>
          <div className="metric-card">
            <div className="metric-label">Total Spent</div>
            <div className="metric-value">₨{Math.round(totalSpent/1000)}k</div>
            <div className="metric-unit">all time</div>
          </div>
          <div className="metric-card">
            <div className="metric-label">Avg Mileage</div>
            <div className="metric-value">{Math.round(avgMileage*10)/10}</div>
            <div className="metric-unit">km / liter</div>
          </div>
          <div className="metric-card">
            <div className="metric-label">Total Fuel</div>
            <div className="metric-value">{Math.round(totalLiters)}</div>
            <div className="metric-unit">liters</div>
          </div>
        </div>

        {/* Chart */}
        {chartData.length > 1 && (
          <div className="glass-card animate-in delay-1" style={{ padding:16, marginBottom:16 }}>
            <div className="section-label" style={{ marginBottom:12 }}>Mileage Trend (km/L)</div>
            <ResponsiveContainer width="100%" height={120}>
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="fuelGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" tick={{ fontSize:10, fill:'var(--text-muted)' }} axisLine={false} tickLine={false}/>
                <YAxis hide domain={['auto','auto']}/>
                <Tooltip content={<CustomTooltip/>}/>
                <Area type="monotone" dataKey="mileage" stroke="#3b82f6" strokeWidth={2} fill="url(#fuelGrad)" dot={false}/>
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Filter */}
        <div className="h-scroll animate-in delay-2" style={{ marginBottom:14 }}>
          {['all','may','apr','mar'].map(f=>(
            <button key={f} onClick={()=>setFilter(f)} className="btn-ghost"
              style={{ borderRadius:20, padding:'6px 14px', fontSize:12, flexShrink:0,
                background: filter===f ? 'var(--accent)' : 'var(--bg-card)',
                color: filter===f ? '#fff' : 'var(--text-secondary)',
                border: filter===f ? 'none' : '1px solid var(--border)' }}>
              {f==='all'?'All Time':f.charAt(0).toUpperCase()+f.slice(1)+' 2025'}
            </button>
          ))}
        </div>

        {/* Entries */}
        <div className="section-label animate-in delay-2">Fuel Log</div>
        {entries.map((e,i) => (
          <div key={e.id} className="glass-card animate-in" style={{ padding:'14px 16px', marginBottom:10,
            animationDelay:`${0.05*i}s` }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
              <div style={{ flex:1 }}>
                <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:4 }}>
                  <span style={{ fontSize:16 }}>⛽</span>
                  <span style={{ fontSize:14, fontWeight:600, color:'var(--text-primary)' }}>{e.station}</span>
                </div>
                <div style={{ fontSize:12, color:'var(--text-secondary)', marginBottom:6 }}>{e.date}</div>
                <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
                  <span className="badge badge-info">{e.liters}L</span>
                  {e.mileage && <span className="badge badge-success">{Math.round(e.mileage*10)/10} km/L</span>}
                  <span style={{ fontSize:11, color:'var(--text-muted)', display:'flex', alignItems:'center' }}>
                    {e.odometer.toLocaleString()} km
                  </span>
                </div>
              </div>
              <div style={{ textAlign:'right' }}>
                <div style={{ fontFamily:"'Rajdhani',sans-serif", fontSize:20, fontWeight:700, color:'var(--accent)' }}>
                  ₨{e.totalCost.toLocaleString()}
                </div>
                <div style={{ fontSize:11, color:'var(--text-muted)' }}>₨{Math.round(e.pricePerLiter)}/L</div>
              </div>
            </div>
          </div>
        ))}

        {entries.length === 0 && (
          <div style={{ textAlign:'center', padding:'40px 20px', color:'var(--text-muted)' }}>
            <div style={{ fontSize:40, marginBottom:12 }}>⛽</div>
            <div style={{ fontSize:14 }}>No fuel entries yet</div>
            <div style={{ fontSize:12, marginTop:4 }}>Tap "+ Add" to record your first fillup</div>
          </div>
        )}
      </div>

      {showModal && <FuelModal onClose={()=>setShowModal(false)} onSave={addEntry} vehicleId={v.id}/>}
    </div>
  );
}
