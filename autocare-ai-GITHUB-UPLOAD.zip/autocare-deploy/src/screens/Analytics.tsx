import React, { useContext } from 'react';
import { AppContext } from '../App';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, AreaChart, Area, PieChart, Pie, Cell, Legend } from 'recharts';

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background:'var(--bg-secondary)', border:'1px solid var(--border)', borderRadius:8, padding:'8px 12px', fontSize:12 }}>
      <div style={{ color:'var(--text-secondary)', marginBottom:4 }}>{label}</div>
      {payload.map((p:any,i:number) => (
        <div key={i} style={{ color:p.color || 'var(--accent)', fontWeight:600 }}>
          {p.name}: {typeof p.value === 'number' ? Math.round(p.value*10)/10 : p.value}
        </div>
      ))}
    </div>
  );
};

export default function Analytics() {
  const { vehicles, activeVehicle, fuelEntries, oilRecords } = useContext(AppContext);
  const v = vehicles[activeVehicle];
  const fuel = fuelEntries.filter(f=>f.vehicleId===v.id);
  const oils = oilRecords.filter(o=>o.vehicleId===v.id);

  const monthlyFuel = [
    { month:'Jan', cost:12400, liters:82 },
    { month:'Feb', cost:11800, liters:78 },
    { month:'Mar', cost:13200, liters:88 },
    { month:'Apr', cost:13500, liters:90 },
    { month:'May', cost:fuel.filter(f=>f.date.startsWith('2025-05')).reduce((a,f)=>a+f.totalCost,0)||6750, liters:45 },
  ];

  const mileageData = [...fuel].reverse().map(f => ({
    date: f.date.slice(5), mileage: f.mileage||0, liters: f.liters
  }));

  const expenseBreakdown = [
    { name:'Fuel', value: fuel.reduce((a,f)=>a+f.totalCost,0), color:'#3b82f6' },
    { name:'Oil Changes', value: oils.reduce((a,o)=>a+o.cost,0), color:'#10b981' },
    { name:'Service', value: 12000, color:'#8b5cf6' },
    { name:'Parts', value: 5500, color:'#f59e0b' },
  ];
  const totalExp = expenseBreakdown.reduce((a,e)=>a+e.value,0);

  const fuelEff = [
    { month:'Jan', avg:13.5 }, { month:'Feb', avg:14.1 }, { month:'Mar', avg:13.8 },
    { month:'Apr', avg:14.2 }, { month:'May', avg:14.0 },
  ];

  return (
    <div>
      <div className="screen-header">
        <div className="screen-title">Analytics</div>
        <div className="screen-subtitle">{v.name} · Performance insights</div>
      </div>

      <div style={{padding:'16px'}}>
        {/* KPIs */}
        <div className="metric-row animate-in" style={{marginBottom:16}}>
          <div className="metric-card">
            <div className="metric-label">Total Expenses</div>
            <div className="metric-value">₨{Math.round(totalExp/1000)}k</div>
            <div className="metric-unit">all time</div>
          </div>
          <div className="metric-card">
            <div className="metric-label">Avg Mileage</div>
            <div className="metric-value">
              {Math.round(fuel.filter(f=>f.mileage).reduce((a,f)=>a+(f.mileage||0),0)/(fuel.filter(f=>f.mileage).length||1)*10)/10}
            </div>
            <div className="metric-unit">km / liter</div>
          </div>
        </div>

        {/* Monthly Fuel Cost */}
        <div className="glass-card animate-in delay-1" style={{padding:'16px',marginBottom:14}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
            <div className="section-label" style={{margin:0}}>Monthly Fuel Cost</div>
            <span className="badge badge-info">₨/month</span>
          </div>
          <ResponsiveContainer width="100%" height={150}>
            <BarChart data={monthlyFuel} barSize={20}>
              <XAxis dataKey="month" tick={{fontSize:11,fill:'var(--text-muted)'}} axisLine={false} tickLine={false}/>
              <YAxis hide/>
              <Tooltip content={<CustomTooltip/>}/>
              <Bar dataKey="cost" name="Cost ₨" fill="#3b82f6" radius={[6,6,0,0]}/>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Fuel Efficiency */}
        <div className="glass-card animate-in delay-2" style={{padding:'16px',marginBottom:14}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
            <div className="section-label" style={{margin:0}}>Fuel Efficiency Trend</div>
            <span className="badge badge-success">km/L</span>
          </div>
          <ResponsiveContainer width="100%" height={130}>
            <AreaChart data={fuelEff}>
              <defs>
                <linearGradient id="effGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis dataKey="month" tick={{fontSize:11,fill:'var(--text-muted)'}} axisLine={false} tickLine={false}/>
              <YAxis hide domain={[12,16]}/>
              <Tooltip content={<CustomTooltip/>}/>
              <Area type="monotone" dataKey="avg" name="Avg km/L" stroke="#10b981" strokeWidth={2.5} fill="url(#effGrad)" dot={{fill:'#10b981',r:3}}/>
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Expense Breakdown */}
        <div className="glass-card animate-in delay-3" style={{padding:'16px',marginBottom:14}}>
          <div className="section-label" style={{marginBottom:14}}>Expense Breakdown</div>
          <div style={{display:'flex',alignItems:'center',gap:16}}>
            <PieChart width={120} height={120}>
              <Pie data={expenseBreakdown} cx={55} cy={55} innerRadius={30} outerRadius={55}
                dataKey="value" strokeWidth={0}>
                {expenseBreakdown.map((e,i) => <Cell key={i} fill={e.color}/>)}
              </Pie>
            </PieChart>
            <div style={{flex:1}}>
              {expenseBreakdown.map(e => (
                <div key={e.name} style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:8}}>
                  <div style={{display:'flex',alignItems:'center',gap:8}}>
                    <div style={{width:8,height:8,borderRadius:'50%',background:e.color,flexShrink:0}}/>
                    <span style={{fontSize:12,color:'var(--text-secondary)'}}>{e.name}</span>
                  </div>
                  <div style={{textAlign:'right'}}>
                    <div style={{fontSize:12,fontWeight:600,color:'var(--text-primary)'}}>₨{Math.round(e.value/1000)}k</div>
                    <div style={{fontSize:10,color:'var(--text-muted)'}}>{Math.round(e.value/totalExp*100)}%</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* AI Insights */}
        <div className="glass-card animate-in delay-4" style={{
          padding:16, background:'rgba(59,130,246,0.06)',
          border:'1px solid rgba(59,130,246,0.2)', marginBottom:16
        }}>
          <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:14}}>
            <div style={{width:32,height:32,borderRadius:8,background:'linear-gradient(135deg,#3b82f6,#8b5cf6)',
              display:'flex',alignItems:'center',justifyContent:'center',fontSize:16,flexShrink:0}}>🤖</div>
            <div>
              <div style={{fontSize:14,fontWeight:600,color:'var(--text-primary)'}}>AI Insights</div>
              <div style={{fontSize:11,color:'var(--text-secondary)'}}>Based on your driving patterns</div>
            </div>
          </div>
          {[
            { icon:'📈', text:'Your mileage improved 4.5% vs last month. Keep maintaining steady speeds.' },
            { icon:'💰', text:'Switching to Shell or Total Parco stations saves you ~₨200 per fill based on your history.' },
            { icon:'🔧', text:'Based on mileage, schedule next service in approximately 2,800 km.' },
            { icon:'⛽', text:'Best fill-up day: Tuesdays show 3% lower fuel prices at your frequent stations.' },
          ].map((insight,i) => (
            <div key={i} style={{display:'flex',gap:10,padding:'10px 0',
              borderTop: i>0 ? '1px solid var(--border)':undefined}}>
              <span style={{fontSize:16,flexShrink:0}}>{insight.icon}</span>
              <span style={{fontSize:12,color:'var(--text-secondary)',lineHeight:1.5}}>{insight.text}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
