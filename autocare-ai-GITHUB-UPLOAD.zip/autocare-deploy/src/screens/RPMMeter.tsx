import React, { useState, useEffect, useRef, useCallback } from 'react';

function polarToXY(cx:number, cy:number, r:number, deg:number) {
  const rad = ((deg - 90) * Math.PI) / 180;
  return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
}

function describeArc(cx:number, cy:number, r:number, startDeg:number, endDeg:number) {
  const s = polarToXY(cx, cy, r, startDeg);
  const e = polarToXY(cx, cy, r, endDeg);
  const large = endDeg - startDeg > 180 ? 1 : 0;
  return `M ${s.x} ${s.y} A ${r} ${r} 0 ${large} 1 ${e.x} ${e.y}`;
}

export default function RPMMeter() {
  const [rpm, setRpm] = useState(0);
  const [speed, setSpeed] = useState(0);
  const [running, setRunning] = useState(false);
  const [gear, setGear] = useState(1);
  const [mode, setMode] = useState<'idle'|'eco'|'sport'>('idle');
  const [throttle, setThrottle] = useState(0);
  const animRef = useRef<number>(0);
  const targetRpm = useRef(0);

  const MAX_RPM = 8000;
  const REDLINE = 6500;
  const cx = 160, cy = 160, R = 130;
  const START_DEG = -220, END_DEG = 50;
  const totalDeg = END_DEG - START_DEG; // 270 deg

  const rpmDeg = START_DEG + (rpm / MAX_RPM) * totalDeg;
  const needleEnd = polarToXY(cx, cy, R - 20, rpmDeg);
  const needleBase1 = polarToXY(cx, cy, 14, rpmDeg - 90);
  const needleBase2 = polarToXY(cx, cy, 14, rpmDeg + 90);

  // Smooth animation
  useEffect(() => {
    const animate = () => {
      setRpm(prev => {
        const diff = targetRpm.current - prev;
        const next = prev + diff * 0.08;
        return Math.abs(diff) < 1 ? targetRpm.current : next;
      });
      setSpeed(prev => {
        const targetSpeed = (targetRpm.current / MAX_RPM) * (gear * 40);
        const diff = targetSpeed - prev;
        return prev + diff * 0.06;
      });
      animRef.current = requestAnimationFrame(animate);
    };
    animRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animRef.current!);
  }, [gear]);

  // Simulation
  useEffect(() => {
    if (!running) { targetRpm.current = 800; return; }
    const patterns = {
      idle: [800, 900, 850, 950, 800],
      eco: [1500, 2000, 2500, 2000, 1800, 2200, 2600, 2200],
      sport: [3000, 4500, 5500, 6000, 4000, 5000, 6500, 5500, 4000],
    };
    let idx = 0;
    const p = patterns[mode];
    const interval = setInterval(() => {
      targetRpm.current = p[idx % p.length] + (Math.random() - 0.5) * 200;
      idx++;
    }, mode === 'sport' ? 600 : 1000);
    return () => clearInterval(interval);
  }, [running, mode]);

  const getColor = (r: number) => {
    if (r >= REDLINE) return '#ef4444';
    if (r >= 5000) return '#f59e0b';
    if (r >= 3000) return '#3b82f6';
    return '#10b981';
  };

  const arcColor = getColor(rpm);

  // Tick marks
  const ticks = [];
  for (let i = 0; i <= MAX_RPM; i += 500) {
    const deg = START_DEG + (i / MAX_RPM) * totalDeg;
    const isMajor = i % 1000 === 0;
    const inner = R - (isMajor ? 18 : 10);
    const outer = R - 2;
    const s = polarToXY(cx, cy, inner, deg);
    const e = polarToXY(cx, cy, outer, deg);
    const isRed = i >= REDLINE;
    ticks.push(<line key={i} x1={s.x} y1={s.y} x2={e.x} y2={e.y}
      stroke={isRed ? '#ef4444' : 'rgba(255,255,255,0.25)'}
      strokeWidth={isMajor ? 2 : 1} strokeLinecap="round"/>);
    if (isMajor) {
      const lp = polarToXY(cx, cy, R - 32, deg);
      ticks.push(<text key={`l${i}`} x={lp.x} y={lp.y} textAnchor="middle" dominantBaseline="middle"
        fontSize="10" fill={isRed ? '#ef4444' : 'rgba(255,255,255,0.45)'} fontFamily="'JetBrains Mono',monospace">
        {i/1000}
      </text>);
    }
  }

  return (
    <div>
      <div className="screen-header">
        <div className="screen-title">Live Monitor</div>
        <div className="screen-subtitle">Real-time engine data simulation</div>
      </div>

      <div style={{ padding:'16px' }}>
        {/* Mode selector */}
        <div style={{ display:'flex', gap:8, marginBottom:16 }} className="animate-in">
          {(['idle','eco','sport'] as const).map(m => (
            <button key={m} onClick={() => setMode(m)}
              style={{ flex:1, padding:'10px 0', borderRadius:12, cursor:'pointer',
                background: mode===m ? (m==='sport'?'var(--danger)':m==='eco'?'var(--success)':'var(--accent)') : 'var(--bg-card)',
                border: `1px solid ${mode===m ? 'transparent' : 'var(--border)'}`,
                color: mode===m ? '#fff' : 'var(--text-secondary)',
                fontSize:13, fontWeight:600, textTransform:'uppercase', letterSpacing:.5,
                transition:'all 0.2s' }}>
              {m}
            </button>
          ))}
        </div>

        {/* Tachometer */}
        <div className="glass-card animate-in delay-1" style={{ padding:20, marginBottom:16, textAlign:'center' }}>
          <svg viewBox="0 0 320 240" width="100%" style={{ maxWidth:320, margin:'0 auto', display:'block' }}>
            {/* Background */}
            <circle cx={cx} cy={cy} r={R+8} fill="rgba(13,18,32,0.8)"/>
            <circle cx={cx} cy={cy} r={R+4} fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="1"/>

            {/* Track */}
            <path d={describeArc(cx, cy, R, START_DEG, END_DEG)} fill="none"
              stroke="rgba(255,255,255,0.06)" strokeWidth="6" strokeLinecap="round"/>

            {/* Redline zone */}
            <path d={describeArc(cx, cy, R, START_DEG + (REDLINE/MAX_RPM)*totalDeg, END_DEG)} fill="none"
              stroke="rgba(239,68,68,0.25)" strokeWidth="6" strokeLinecap="round"/>

            {/* Active arc */}
            {rpm > 100 && <path d={describeArc(cx, cy, R, START_DEG, rpmDeg)} fill="none"
              stroke={arcColor} strokeWidth="6" strokeLinecap="round"
              style={{filter:`drop-shadow(0 0 6px ${arcColor}80)`}}/>}

            {/* Ticks */}
            {ticks}

            {/* Needle */}
            <polygon points={`${needleEnd.x},${needleEnd.y} ${needleBase1.x},${needleBase1.y} ${needleBase2.x},${needleBase2.y}`}
              fill={arcColor} opacity="0.9"/>
            <circle cx={cx} cy={cy} r="12" fill="rgba(20,24,40,1)" stroke={arcColor} strokeWidth="2"/>
            <circle cx={cx} cy={cy} r="5" fill={arcColor}/>

            {/* RPM reading */}
            <text x={cx} y={cy+38} textAnchor="middle" fontSize="32"
              fontFamily="'Rajdhani',sans-serif" fontWeight="700" fill="white">
              {Math.round(rpm).toLocaleString()}
            </text>
            <text x={cx} y={cy+55} textAnchor="middle" fontSize="10"
              fill="rgba(255,255,255,0.4)" fontFamily="'Inter',sans-serif" letterSpacing="2">
              RPM
            </text>
          </svg>

          {/* Speed display */}
          <div style={{ display:'flex', justifyContent:'center', gap:32, marginTop:8 }}>
            <div style={{ textAlign:'center' }}>
              <div style={{ fontFamily:"'Rajdhani',sans-serif", fontSize:32, fontWeight:700, color:'white' }}>
                {Math.round(speed)}
              </div>
              <div style={{ fontSize:10, color:'rgba(255,255,255,0.35)', textTransform:'uppercase', letterSpacing:1 }}>km/h</div>
            </div>
            <div style={{ textAlign:'center' }}>
              <div style={{ fontFamily:"'Rajdhani',sans-serif", fontSize:32, fontWeight:700, color:arcColor }}>
                {gear}
              </div>
              <div style={{ fontSize:10, color:'rgba(255,255,255,0.35)', textTransform:'uppercase', letterSpacing:1 }}>gear</div>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div style={{ display:'flex', gap:10, marginBottom:16 }} className="animate-in delay-2">
          <button className={running ? 'btn-primary' : 'btn-ghost'} style={{ flex:1 }}
            onClick={() => { setRunning(r=>!r); if (running) { targetRpm.current=0; setGear(1); }}}>
            {running ? '⏹ Stop Engine' : '▶ Start Engine'}
          </button>
          {running && (
            <div style={{ display:'flex', gap:6 }}>
              <button className="btn-ghost" style={{padding:'10px 14px'}} onClick={()=>setGear(g=>Math.max(1,g-1))}>▼</button>
              <button className="btn-ghost" style={{padding:'10px 14px'}} onClick={()=>setGear(g=>Math.min(6,g+1))}>▲</button>
            </div>
          )}
        </div>

        {/* Throttle */}
        <div className="glass-card animate-in delay-2" style={{padding:16, marginBottom:16}}>
          <div style={{ display:'flex', justifyContent:'space-between', marginBottom:10 }}>
            <span style={{ fontSize:13, color:'var(--text-secondary)' }}>Manual Throttle</span>
            <span style={{ fontSize:13, fontWeight:600, color:'var(--accent)' }}>{throttle}%</span>
          </div>
          <input type="range" min="0" max="100" value={throttle}
            onChange={e=>{ setThrottle(+e.target.value); if(running) targetRpm.current = (+e.target.value/100)*MAX_RPM; }}
            style={{ width:'100%', accentColor:'var(--accent)' }}/>
        </div>

        {/* Live metrics */}
        <div className="metric-row animate-in delay-3">
          <div className="metric-card">
            <div className="metric-label">Engine Temp</div>
            <div className="metric-value" style={{color: running?'var(--warning)':'var(--success)'}}>
              {running ? Math.round(85 + rpm/400) : 22}°C
            </div>
          </div>
          <div className="metric-card">
            <div className="metric-label">Oil Pressure</div>
            <div className="metric-value">{running ? Math.round(35 + rpm/300) : 0}</div>
            <div className="metric-unit">psi</div>
          </div>
          <div className="metric-card">
            <div className="metric-label">Voltage</div>
            <div className="metric-value">{running ? 14.2 : 12.6}</div>
            <div className="metric-unit">V</div>
          </div>
        </div>

        {rpm >= REDLINE && (
          <div style={{ marginTop:12, padding:'12px 16px', background:'rgba(239,68,68,0.15)',
            border:'1px solid rgba(239,68,68,0.4)', borderRadius:12, textAlign:'center',
            animation:'pulse 0.5s ease infinite alternate', color:'var(--danger)', fontWeight:600 }}>
            ⚠️ REDLINE — Ease off throttle!
          </div>
        )}
      </div>
    </div>
  );
}
