import React, { useContext, useState, useEffect } from 'react';
import { AppContext } from '../App';
import { useTheme } from '../App';

function CircleProgress({ value, max, size=80, color='#3b82f6', label, unit }:
  { value:number; max:number; size?:number; color?:string; label:string; unit:string }) {
  const r = (size-14)/2;
  const circ = 2*Math.PI*r;
  const [dash, setDash] = useState(circ);
  useEffect(() => { setTimeout(() => setDash(circ - (value/max)*circ), 100); }, [value,max,circ]);
  return (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:4 }}>
      <svg width={size} height={size} style={{transform:'rotate(-90deg)'}}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="6"/>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth="6"
          strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={dash}
          style={{transition:'stroke-dashoffset 1.2s cubic-bezier(0.4,0,0.2,1)'}}/>
      </svg>
      <div style={{ position:'relative', marginTop:-size/2-14, display:'flex', flexDirection:'column', alignItems:'center', height:size/2 }}>
        <span style={{ fontFamily:"'Rajdhani',sans-serif", fontSize:size/3.8, fontWeight:700, color:'var(--text-primary)', lineHeight:1 }}>
          {value}
        </span>
        <span style={{ fontSize:9, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:.5 }}>{unit}</span>
      </div>
      <span style={{ fontSize:10, color:'var(--text-secondary)', textAlign:'center', marginTop:size/2-8 }}>{label}</span>
    </div>
  );
}

function AlertCard({ icon, title, desc, type }: { icon:string; title:string; desc:string; type:'success'|'warning'|'danger' }) {
  const colors = { success:'var(--success)', warning:'var(--warning)', danger:'var(--danger)' };
  const bgs = { success:'rgba(16,185,129,0.08)', warning:'rgba(245,158,11,0.08)', danger:'rgba(239,68,68,0.08)' };
  return (
    <div style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 14px',
      background:bgs[type], border:`1px solid ${colors[type]}30`, borderRadius:12, marginBottom:8 }}>
      <div style={{ fontSize:20, flexShrink:0 }}>{icon}</div>
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontSize:13, fontWeight:600, color:'var(--text-primary)' }}>{title}</div>
        <div style={{ fontSize:11, color:'var(--text-secondary)', marginTop:1 }}>{desc}</div>
      </div>
      <div style={{ width:8, height:8, borderRadius:'50%', background:colors[type], flexShrink:0 }}/>
    </div>
  );
}

export default function Dashboard() {
  const { vehicles, activeVehicle, setActiveVehicle, fuelEntries, oilRecords, setScreen } = useContext(AppContext);
  const { dark, toggle } = useTheme();
  const v = vehicles[activeVehicle];
  const vFuel = fuelEntries.filter(f => f.vehicleId===v.id);
  const vOil = oilRecords.filter(o => o.vehicleId===v.id);
  const lastOil = vOil[0];
  const remainingKm = lastOil ? lastOil.nextDueKm - v.odometer : 0;
  const oilPct = lastOil ? Math.max(0, Math.min(100, (remainingKm/lastOil.intervalKm)*100)) : 100;
  const avgMileage = vFuel.filter(f=>f.mileage).reduce((a,f)=>a+(f.mileage||0),0) / (vFuel.filter(f=>f.mileage).length||1);
  const thisMonthFuel = vFuel.filter(f=>f.date.startsWith('2025-05')).reduce((a,f)=>a+f.totalCost,0);
  const lastFuel = vFuel[0];

  return (
    <div style={{ padding:'56px 16px 16px' }}>
      {/* Header */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:20 }}>
        <div>
          <div style={{ fontSize:12, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:1, marginBottom:4 }}>
            Good morning
          </div>
          <div style={{ fontFamily:"'Rajdhani',sans-serif", fontSize:26, fontWeight:700, color:'var(--text-primary)', lineHeight:1 }}>
            Vehicle Status
          </div>
        </div>
        <div style={{ display:'flex', gap:8 }}>
          <button onClick={toggle} className="btn-ghost" style={{ padding:'8px 10px', borderRadius:10 }}>
            {dark ? '☀️' : '🌙'}
          </button>
          <div style={{ width:36, height:36, borderRadius:10, background:'linear-gradient(135deg,#3b82f6,#8b5cf6)',
            display:'flex', alignItems:'center', justifyContent:'center', fontSize:16, cursor:'pointer' }}>
            👤
          </div>
        </div>
      </div>

      {/* Vehicle Selector */}
      <div className="h-scroll animate-in" style={{ marginBottom:16 }}>
        {vehicles.map((vh,i) => (
          <div key={vh.id} onClick={() => setActiveVehicle(i)}
            style={{ flexShrink:0, padding:'12px 16px', borderRadius:14,
              background: i===activeVehicle ? `${vh.color}20` : 'var(--bg-card)',
              border: `1px solid ${i===activeVehicle ? vh.color+'60' : 'var(--border)'}`,
              cursor:'pointer', minWidth:130, transition:'all 0.2s' }}>
            <div style={{ fontSize:10, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:.5 }}>{vh.type}</div>
            <div style={{ fontFamily:"'Rajdhani',sans-serif", fontSize:16, fontWeight:700, color:'var(--text-primary)', marginTop:2 }}>{vh.name}</div>
            <div style={{ fontSize:11, color:'var(--text-secondary)' }}>{vh.model}</div>
            <div style={{ marginTop:6, display:'flex', alignItems:'center', gap:4 }}>
              <div style={{ width:6, height:6, borderRadius:'50%', background:vh.color }}/>
              <span style={{ fontSize:10, color:vh.color, fontWeight:600 }}>{vh.regNumber}</span>
            </div>
          </div>
        ))}
        <div onClick={() => setScreen('vehicles')} style={{
          flexShrink:0, padding:'12px 16px', borderRadius:14,
          background:'var(--bg-card)', border:'1px dashed var(--border)',
          cursor:'pointer', minWidth:100, display:'flex', flexDirection:'column',
          alignItems:'center', justifyContent:'center', gap:4
        }}>
          <div style={{ fontSize:20, color:'var(--text-muted)' }}>+</div>
          <div style={{ fontSize:11, color:'var(--text-muted)' }}>Add Vehicle</div>
        </div>
      </div>

      {/* Hero Vehicle Card */}
      <div className="glass-card animate-in delay-1" style={{
        padding:20, marginBottom:16,
        background:`linear-gradient(135deg, ${v.color}15, ${v.color}05)`,
        border:`1px solid ${v.color}30`, position:'relative', overflow:'hidden'
      }}>
        <div style={{ position:'absolute', right:-20, top:-20, width:120, height:120,
          borderRadius:'50%', background:`${v.color}08` }}/>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
          <div>
            <div style={{ fontFamily:"'Rajdhani',sans-serif", fontSize:22, fontWeight:700, color:'var(--text-primary)' }}>
              {v.name}
            </div>
            <div style={{ fontSize:13, color:'var(--text-secondary)' }}>{v.model} · {v.year}</div>
            <div style={{ marginTop:8, display:'flex', gap:6, flexWrap:'wrap' }}>
              <span className="badge badge-info">{v.fuelType}</span>
              <span className="badge badge-success">{v.engineCC > 0 ? `${v.engineCC}cc` : 'Electric'}</span>
            </div>
          </div>
          <div style={{ textAlign:'right' }}>
            <div style={{ fontSize:11, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:.5 }}>Odometer</div>
            <div style={{ fontFamily:"'Rajdhani',sans-serif", fontSize:28, fontWeight:700, color:v.color, lineHeight:1 }}>
              {v.odometer.toLocaleString()}
            </div>
            <div style={{ fontSize:11, color:'var(--text-secondary)' }}>kilometers</div>
          </div>
        </div>

        {/* Progress Gauges */}
        <div style={{ display:'flex', justifyContent:'space-around', marginTop:20, paddingTop:16,
          borderTop:'1px solid rgba(255,255,255,0.08)' }}>
          <CircleProgress value={Math.round(oilPct)} max={100} color={oilPct>50?'#10b981':oilPct>20?'#f59e0b':'#ef4444'} label="Oil Health" unit="%"/>
          <CircleProgress value={Math.round(avgMileage*10)/10} max={20} color={v.color} label="Avg Mileage" unit="km/l"/>
          <CircleProgress value={Math.round(avgMileage*100)/100 > 0 ? 85 : 0} max={100} color="#8b5cf6" label="Engine" unit="%"/>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="metric-row animate-in delay-2" style={{ marginBottom:16 }}>
        <div className="metric-card">
          <div className="metric-label">Next Oil Change</div>
          <div className="metric-value" style={{ color: remainingKm < 500 ? 'var(--danger)' : remainingKm < 1000 ? 'var(--warning)' : 'var(--success)' }}>
            {remainingKm > 0 ? remainingKm.toLocaleString() : 'Overdue'}
          </div>
          <div className="metric-unit">km remaining</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Fuel This Month</div>
          <div className="metric-value">₨{Math.round(thisMonthFuel/1000)}k</div>
          <div className="metric-unit">total spent</div>
        </div>
      </div>

      <div className="metric-row animate-in delay-2" style={{ marginBottom:16 }}>
        <div className="metric-card">
          <div className="metric-label">Last Refuel</div>
          <div className="metric-value">{lastFuel?.liters || '—'}</div>
          <div className="metric-unit">liters · {lastFuel?.date || 'no data'}</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Avg Fuel Cost</div>
          <div className="metric-value">₨{lastFuel?.pricePerLiter || '—'}</div>
          <div className="metric-unit">per liter</div>
        </div>
      </div>

      {/* Alerts */}
      <div className="animate-in delay-3">
        <div className="section-label" style={{ color:'var(--text-muted)', marginBottom:10 }}>Smart Alerts</div>
        {remainingKm < 500 && remainingKm > 0 && (
          <AlertCard icon="⚠️" title="Oil Change Due Soon" desc={`Only ${remainingKm} km remaining`} type="warning"/>
        )}
        {remainingKm <= 0 && (
          <AlertCard icon="🔴" title="Oil Change Overdue" desc="Service immediately recommended" type="danger"/>
        )}
        <AlertCard icon="✅" title="Tire Pressure Normal" desc="All 4 tires within safe range" type="success"/>
        <AlertCard icon="⚡" title="Battery Health Good" desc="96% capacity remaining" type="success"/>
        {thisMonthFuel > 15000 && (
          <AlertCard icon="💰" title="High Fuel Spending" desc="20% above your monthly average" type="warning"/>
        )}
      </div>

      {/* Quick Actions */}
      <div className="animate-in delay-4" style={{ marginTop:16 }}>
        <div className="section-label" style={{ color:'var(--text-muted)', marginBottom:10 }}>Quick Actions</div>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
          {[
            { label:'Add Fuel', icon:'⛽', screen:'fuel', color:'#3b82f6' },
            { label:'Log Oil Change', icon:'🔧', screen:'oil', color:'#10b981' },
            { label:'Live Monitor', icon:'📊', screen:'rpm', color:'#8b5cf6' },
            { label:'View Analytics', icon:'📈', screen:'analytics', color:'#f59e0b' },
          ].map(a => (
            <button key={a.label} onClick={() => setScreen(a.screen as any)}
              style={{ padding:'14px', borderRadius:14, background:`${a.color}12`,
                border:`1px solid ${a.color}30`, cursor:'pointer', textAlign:'left',
                transition:'all 0.2s', display:'flex', alignItems:'center', gap:10 }}>
              <span style={{ fontSize:20 }}>{a.icon}</span>
              <span style={{ fontSize:13, fontWeight:600, color:'var(--text-primary)' }}>{a.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
