import React, { useContext, useState } from 'react';
import { AppContext, Vehicle } from '../App';

const VEHICLE_ICONS: Record<string, string> = { car:'🚗', bike:'🏍️', van:'🚐', truck:'🚚' };
const COLORS = ['#3b82f6','#8b5cf6','#10b981','#f59e0b','#ef4444','#06b6d4','#ec4899'];

function AddVehicleModal({ onClose, onSave }: { onClose:()=>void; onSave:(v:Vehicle)=>void }) {
  const [form, setForm] = useState({
    name:'', model:'', year:String(new Date().getFullYear()), regNumber:'',
    fuelType:'Petrol', engineCC:'1300', type:'car', odometer:'0', color:'#3b82f6'
  });
  const set = (k:string,v:string) => setForm(f=>({...f,[k]:v}));
  const save = () => {
    if (!form.name || !form.model) return;
    onSave({ id:Date.now().toString(), name:form.name, model:form.model, year:+form.year,
      regNumber:form.regNumber, fuelType:form.fuelType, engineCC:+form.engineCC,
      type:form.type as any, odometer:+form.odometer, color:form.color });
    onClose();
  };
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-sheet" onClick={e=>e.stopPropagation()}>
        <div className="modal-handle"/>
        <div style={{ fontFamily:"'Rajdhani',sans-serif", fontSize:22, fontWeight:700, color:'var(--text-primary)', marginBottom:20 }}>
          Add Vehicle
        </div>

        {/* Type Selector */}
        <div className="form-group">
          <label className="form-label">Vehicle Type</label>
          <div style={{ display:'flex', gap:8 }}>
            {(['car','bike','van','truck'] as const).map(t => (
              <button key={t} onClick={()=>set('type',t)}
                style={{ flex:1, padding:'10px 4px', borderRadius:10, cursor:'pointer',
                  background: form.type===t ? 'var(--accent)' : 'var(--bg-card)',
                  border: `1px solid ${form.type===t ? 'transparent' : 'var(--border)'}`,
                  color: form.type===t ? '#fff' : 'var(--text-secondary)',
                  fontSize:18, display:'flex', flexDirection:'column', alignItems:'center', gap:2 }}>
                <span>{VEHICLE_ICONS[t]}</span>
                <span style={{ fontSize:9, textTransform:'uppercase', letterSpacing:.5 }}>{t}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Color Picker */}
        <div className="form-group">
          <label className="form-label">Color</label>
          <div style={{ display:'flex', gap:8 }}>
            {COLORS.map(c => (
              <button key={c} onClick={()=>set('color',c)}
                style={{ width:28, height:28, borderRadius:'50%', background:c, border:'none', cursor:'pointer',
                  outline: form.color===c ? `3px solid ${c}` : '3px solid transparent',
                  outlineOffset:2, transition:'all 0.15s' }}/>
            ))}
          </div>
        </div>

        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
          <div className="form-group" style={{gridColumn:'1/-1'}}>
            <label className="form-label">Nickname</label>
            <input className="form-input" placeholder="My Civic" value={form.name} onChange={e=>set('name',e.target.value)}/>
          </div>
          <div className="form-group">
            <label className="form-label">Model</label>
            <input className="form-input" placeholder="Civic 1.5T" value={form.model} onChange={e=>set('model',e.target.value)}/>
          </div>
          <div className="form-group">
            <label className="form-label">Year</label>
            <input className="form-input" type="number" value={form.year} onChange={e=>set('year',e.target.value)}/>
          </div>
          <div className="form-group" style={{gridColumn:'1/-1'}}>
            <label className="form-label">Registration Number</label>
            <input className="form-input" placeholder="KHI-1234" value={form.regNumber} onChange={e=>set('regNumber',e.target.value)}/>
          </div>
          <div className="form-group">
            <label className="form-label">Fuel Type</label>
            <select className="form-input" value={form.fuelType} onChange={e=>set('fuelType',e.target.value)}>
              {['Petrol','Diesel','CNG','Electric','Hybrid'].map(f=><option key={f}>{f}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Engine (cc)</label>
            <input className="form-input" type="number" placeholder="1300" value={form.engineCC} onChange={e=>set('engineCC',e.target.value)}/>
          </div>
          <div className="form-group" style={{gridColumn:'1/-1'}}>
            <label className="form-label">Current Odometer (KM)</label>
            <input className="form-input" type="number" placeholder="0" value={form.odometer} onChange={e=>set('odometer',e.target.value)}/>
          </div>
        </div>

        <div style={{ display:'flex', gap:10, marginTop:8 }}>
          <button className="btn-ghost" style={{flex:1}} onClick={onClose}>Cancel</button>
          <button className="btn-primary" style={{flex:2}} onClick={save}>Add Vehicle</button>
        </div>
      </div>
    </div>
  );
}

export default function Vehicles() {
  const { vehicles, setVehicles, activeVehicle, setActiveVehicle, fuelEntries, oilRecords } = useContext(AppContext);
  const [showModal, setShowModal] = useState(false);
  const [selected, setSelected] = useState<string|null>(null);

  const addVehicle = (v: Vehicle) => setVehicles([...vehicles, v]);
  const removeVehicle = (id: string) => {
    const idx = vehicles.findIndex(v=>v.id===id);
    setVehicles(vehicles.filter(v=>v.id!==id));
    if (activeVehicle >= vehicles.length - 1) setActiveVehicle(0);
    setSelected(null);
  };

  return (
    <div>
      <div className="screen-header">
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <div>
            <div className="screen-title">My Vehicles</div>
            <div className="screen-subtitle">{vehicles.length} registered vehicles</div>
          </div>
          <button className="btn-primary" style={{borderRadius:12}} onClick={()=>setShowModal(true)}>
            <span style={{fontSize:18,lineHeight:1}}>+</span> Add
          </button>
        </div>
      </div>

      <div style={{padding:'16px'}}>
        {/* Fleet Overview */}
        <div className="glass-card animate-in" style={{
          padding:16, marginBottom:16,
          background:'linear-gradient(135deg,rgba(59,130,246,0.1),rgba(139,92,246,0.1))',
          border:'1px solid rgba(59,130,246,0.2)'
        }}>
          <div className="section-label" style={{marginBottom:12}}>Fleet Overview</div>
          <div style={{display:'flex',gap:0}}>
            {[
              { label:'Vehicles', value:vehicles.length },
              { label:'Fuel Records', value:fuelEntries.length },
              { label:'Oil Changes', value:oilRecords.length },
              { label:'Total KM', value:Math.round(vehicles.reduce((a,v)=>a+v.odometer,0)/1000)+'k' },
            ].map((s,i) => (
              <div key={s.label} style={{flex:1, textAlign:'center',
                borderRight: i<3 ? '1px solid var(--border)' : undefined, padding:'0 8px'}}>
                <div style={{fontFamily:"'Rajdhani',sans-serif",fontSize:24,fontWeight:700,color:'var(--text-primary)'}}>
                  {s.value}
                </div>
                <div style={{fontSize:10,color:'var(--text-muted)',textTransform:'uppercase',letterSpacing:.3}}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Vehicle Cards */}
        <div className="section-label animate-in delay-1">Registered Vehicles</div>
        {vehicles.map((v,i) => {
          const vFuel = fuelEntries.filter(f=>f.vehicleId===v.id);
          const vOil = oilRecords.filter(o=>o.vehicleId===v.id);
          const lastOil = vOil[0];
          const remaining = lastOil ? lastOil.nextDueKm - v.odometer : null;
          const isActive = activeVehicle === i;
          const isExpanded = selected === v.id;

          return (
            <div key={v.id} className="animate-in" style={{animationDelay:`${0.06*i}s`, marginBottom:12}}>
              <div className="glass-card" style={{
                border: isActive ? `1px solid ${v.color}50` : '1px solid var(--border)',
                background: isActive ? `${v.color}08` : 'var(--bg-card)',
                overflow:'hidden'
              }}>
                {/* Card Header */}
                <div style={{padding:'16px', cursor:'pointer'}}
                  onClick={()=>setSelected(isExpanded ? null : v.id)}>
                  <div style={{display:'flex',gap:14,alignItems:'flex-start'}}>
                    {/* Icon */}
                    <div style={{width:52,height:52,borderRadius:14,flexShrink:0,
                      background:`${v.color}20`, border:`1px solid ${v.color}30`,
                      display:'flex',alignItems:'center',justifyContent:'center',fontSize:24}}>
                      {VEHICLE_ICONS[v.type]}
                    </div>

                    <div style={{flex:1,minWidth:0}}>
                      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start'}}>
                        <div>
                          <div style={{fontFamily:"'Rajdhani',sans-serif",fontSize:18,fontWeight:700,color:'var(--text-primary)'}}>
                            {v.name}
                          </div>
                          <div style={{fontSize:12,color:'var(--text-secondary)'}}>{v.model} · {v.year}</div>
                        </div>
                        <div style={{display:'flex',gap:6,alignItems:'center'}}>
                          {isActive && <span className="badge badge-success">Active</span>}
                          <span style={{color:'var(--text-muted)',fontSize:16}}>{isExpanded?'▲':'▼'}</span>
                        </div>
                      </div>

                      <div style={{marginTop:8,display:'flex',gap:6,flexWrap:'wrap'}}>
                        <span className="badge badge-info">{v.fuelType}</span>
                        <span style={{fontSize:11,color:'var(--text-muted)',display:'flex',alignItems:'center',gap:3}}>
                          <div style={{width:6,height:6,borderRadius:'50%',background:v.color}}/>
                          {v.regNumber}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Quick Stats Bar */}
                  <div style={{display:'flex',gap:0,marginTop:14,paddingTop:12,
                    borderTop:'1px solid var(--border)'}}>
                    {[
                      {label:'Odometer', value:`${v.odometer.toLocaleString()} km`},
                      {label:'Fuel Logs', value:vFuel.length},
                      {label:'Oil Due', value: remaining !== null ? (remaining > 0 ? `${remaining.toLocaleString()} km` : 'Overdue') : 'N/A'},
                    ].map((s,j)=>(
                      <div key={s.label} style={{flex:1, textAlign:'center',
                        borderRight: j<2 ? '1px solid var(--border)' : undefined}}>
                        <div style={{fontFamily:"'Rajdhani',sans-serif",fontSize:15,fontWeight:700,
                          color: s.label==='Oil Due' && remaining !== null && remaining < 500 ? 'var(--danger)' : 'var(--text-primary)'}}>
                          {s.value}
                        </div>
                        <div style={{fontSize:10,color:'var(--text-muted)',textTransform:'uppercase',letterSpacing:.3}}>
                          {s.label}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Expanded Actions */}
                {isExpanded && (
                  <div style={{padding:'0 16px 16px', borderTop:'1px solid var(--border)'}}>
                    <div style={{paddingTop:14,display:'flex',gap:8,flexWrap:'wrap'}}>
                      {!isActive && (
                        <button className="btn-primary" style={{flex:1}}
                          onClick={()=>{setActiveVehicle(i);setSelected(null);}}>
                          Set as Active
                        </button>
                      )}
                      <button className="btn-ghost" style={{flex:1,fontSize:12}}>
                        Edit Details
                      </button>
                      {vehicles.length > 1 && (
                        <button onClick={()=>removeVehicle(v.id)}
                          style={{padding:'10px 14px',borderRadius:10,border:'1px solid rgba(239,68,68,0.3)',
                            background:'rgba(239,68,68,0.08)',color:'var(--danger)',
                            cursor:'pointer',fontSize:13,fontWeight:500}}>
                          Remove
                        </button>
                      )}
                    </div>

                    {/* Engine Info */}
                    {v.engineCC > 0 && (
                      <div style={{marginTop:12,padding:'12px',background:'var(--bg-card)',
                        borderRadius:10,border:'1px solid var(--border)'}}>
                        <div style={{display:'flex',justifyContent:'space-between'}}>
                          <span style={{fontSize:12,color:'var(--text-secondary)'}}>Engine Capacity</span>
                          <span style={{fontSize:13,fontWeight:600,color:'var(--text-primary)'}}>
                            {v.engineCC >= 1000 ? `${v.engineCC/1000}L` : `${v.engineCC}cc`}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {/* Insurance / Docs Section */}
        <div className="glass-card animate-in delay-3" style={{padding:16,marginTop:8}}>
          <div className="section-label" style={{marginBottom:12}}>Documents & Reminders</div>
          {[
            { icon:'📋', label:'Insurance Expiry', date:'Nov 2025', status:'valid' },
            { icon:'📑', label:'Registration (Token)', date:'Aug 2025', status:'valid' },
            { icon:'🔍', label:'Fitness Certificate', date:'Mar 2026', status:'valid' },
            { icon:'🛞', label:'Tire Change Due', date:'~2,000 km', status:'warning' },
          ].map((d,i) => (
            <div key={i} style={{display:'flex',alignItems:'center',gap:12,padding:'10px 0',
              borderTop: i>0 ? '1px solid var(--border)' : undefined}}>
              <span style={{fontSize:20}}>{d.icon}</span>
              <div style={{flex:1}}>
                <div style={{fontSize:13,fontWeight:500,color:'var(--text-primary)'}}>{d.label}</div>
                <div style={{fontSize:11,color:'var(--text-secondary)'}}>{d.date}</div>
              </div>
              <span className={`badge ${d.status==='warning'?'badge-warning':'badge-success'}`}>
                {d.status==='warning'?'Soon':'OK'}
              </span>
            </div>
          ))}
        </div>
      </div>

      {showModal && <AddVehicleModal onClose={()=>setShowModal(false)} onSave={addVehicle}/>}
    </div>
  );
}
