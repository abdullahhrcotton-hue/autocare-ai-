import React, { useContext } from 'react';
import { AppContext, Screen } from '../App';

const tabs: { id: Screen; label: string; icon: (active: boolean) => React.ReactNode }[] = [
  { id: 'dashboard', label: 'Home', icon: (a) => (
    <svg viewBox="0 0 24 24" fill={a?'currentColor':'none'} stroke="currentColor" strokeWidth="1.8">
      <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>
      <polyline points="9,22 9,12 15,12 15,22"/>
    </svg>
  )},
  { id: 'fuel', label: 'Fuel', icon: (a) => (
    <svg viewBox="0 0 24 24" fill={a?'currentColor':'none'} stroke="currentColor" strokeWidth="1.8">
      <path d="M3 22V8a2 2 0 012-2h8a2 2 0 012 2v14"/>
      <path d="M3 22h12M15 8l3 3v8a1 1 0 002 0V9l-2-2"/>
      <rect x="6" y="10" width="5" height="4" rx="1" fill={a?'white':'none'}/>
    </svg>
  )},
  { id: 'oil', label: 'Oil', icon: (a) => (
    <svg viewBox="0 0 24 24" fill={a?'currentColor':'none'} stroke="currentColor" strokeWidth="1.8">
      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"/>
      <path d="M12 6v6l4 2" strokeLinecap="round"/>
    </svg>
  )},
  { id: 'rpm', label: 'Live', icon: (a) => (
    <svg viewBox="0 0 24 24" fill={a?'currentColor':'none'} stroke="currentColor" strokeWidth="1.8">
      <circle cx="12" cy="12" r="10"/>
      <path d="M12 8v4l3 3" strokeLinecap="round"/>
      <path d="M8.5 8.5L6 6M15.5 8.5L18 6" strokeLinecap="round"/>
    </svg>
  )},
  { id: 'analytics', label: 'Stats', icon: (a) => (
    <svg viewBox="0 0 24 24" fill={a?'currentColor':'none'} stroke="currentColor" strokeWidth="1.8">
      <line x1="18" y1="20" x2="18" y2="10"/>
      <line x1="12" y1="20" x2="12" y2="4"/>
      <line x1="6" y1="20" x2="6" y2="14"/>
    </svg>
  )},
  { id: 'vehicles', label: 'Cars', icon: (a) => (
    <svg viewBox="0 0 24 24" fill={a?'currentColor':'none'} stroke="currentColor" strokeWidth="1.8">
      <path d="M5 17H3a2 2 0 01-2-2V9a2 2 0 012-2l3-4h12l3 4a2 2 0 012 2v6a2 2 0 01-2 2h-2"/>
      <circle cx="7.5" cy="17.5" r="2.5"/>
      <circle cx="16.5" cy="17.5" r="2.5"/>
    </svg>
  )},
];

export default function BottomNav() {
  const { screen, setScreen } = useContext(AppContext);
  return (
    <nav className="bottom-nav">
      {tabs.map(tab => (
        <button key={tab.id} className={`nav-item${screen===tab.id?' active':''}`} onClick={() => setScreen(tab.id)}>
          {tab.icon(screen===tab.id)}
          <span className="nav-label">{tab.label}</span>
          {screen===tab.id && <span className="nav-dot"/>}
        </button>
      ))}
    </nav>
  );
}
