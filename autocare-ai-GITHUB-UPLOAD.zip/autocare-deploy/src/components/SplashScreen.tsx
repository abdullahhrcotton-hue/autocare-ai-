import React, { useEffect } from 'react';

interface Props { onDone: () => void; }

export default function SplashScreen({ onDone }: Props) {
  useEffect(() => {
    const t = setTimeout(onDone, 3200);
    return () => clearTimeout(t);
  }, [onDone]);

  return (
    <div style={{
      position:'fixed', inset:0, background:'#080c14',
      display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
      zIndex:1000
    }}>
      {[180,280,380].map((size,i) => (
        <div key={i} style={{
          position:'absolute', width:size, height:size,
          borderRadius:'50%', border:'1px solid rgba(59,130,246,0.12)',
          animation:`ringPulse ${1.5+i*0.3}s ease-in-out ${i*0.2}s infinite`
        }}/>
      ))}
      <style>{`
        @keyframes ringPulse{0%,100%{transform:scale(1);opacity:.4}50%{transform:scale(1.06);opacity:.8}}
        @keyframes logoIn{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
        @keyframes barFill{from{width:0}to{width:100%}}
        @keyframes fadeSplash{to{opacity:0;pointer-events:none}}
      `}</style>

      <div style={{ position:'relative', zIndex:1, textAlign:'center' }}>
        <div style={{
          width:72, height:72, borderRadius:20,
          background:'linear-gradient(135deg,#3b82f6,#8b5cf6)',
          display:'flex', alignItems:'center', justifyContent:'center',
          margin:'0 auto 20px',
          animation:'logoIn 0.7s cubic-bezier(0.16,1,0.3,1) 0.2s both'
        }}>
          <svg width="38" height="38" viewBox="0 0 24 24" fill="none">
            <path d="M12 2L2 7l10 5 10-5-10-5z" stroke="white" strokeWidth="1.5" strokeLinejoin="round"/>
            <path d="M2 17l10 5 10-5" stroke="white" strokeWidth="1.5" strokeLinejoin="round"/>
            <path d="M2 12l10 5 10-5" stroke="white" strokeWidth="1.5" strokeLinejoin="round"/>
          </svg>
        </div>

        <div style={{
          fontFamily:"'Rajdhani',sans-serif", fontSize:40, fontWeight:700,
          color:'#f0f4ff', letterSpacing:2,
          animation:'logoIn 0.7s cubic-bezier(0.16,1,0.3,1) 0.35s both'
        }}>
          Auto<span style={{color:'#3b82f6'}}>Care</span>
          <span style={{
            background:'linear-gradient(135deg,#3b82f6,#8b5cf6)',
            WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent',
            marginLeft:6
          }}>AI</span>
        </div>

        <div style={{
          fontSize:11, letterSpacing:4, color:'rgba(240,244,255,0.35)',
          textTransform:'uppercase', marginTop:4,
          animation:'logoIn 0.7s cubic-bezier(0.16,1,0.3,1) 0.5s both'
        }}>
          Intelligent Vehicle Management
        </div>

        <div style={{
          width:180, height:2, background:'rgba(255,255,255,0.06)',
          borderRadius:2, margin:'40px auto 0', overflow:'hidden',
          animation:'logoIn 0.5s ease 0.7s both'
        }}>
          <div style={{
            height:'100%', background:'linear-gradient(90deg,#3b82f6,#8b5cf6)',
            borderRadius:2, animation:'barFill 2s cubic-bezier(0.4,0,0.2,1) 0.9s both'
          }}/>
        </div>

        <div style={{
          fontSize:11, color:'rgba(240,244,255,0.25)', marginTop:12,
          letterSpacing:1, animation:'logoIn 0.5s ease 1s both'
        }}>
          Starting engine...
        </div>
      </div>
    </div>
  );
}
