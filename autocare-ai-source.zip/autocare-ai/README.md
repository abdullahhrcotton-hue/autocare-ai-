# AutoCare AI — Intelligent Vehicle Management App

A premium mobile-first web application for complete vehicle maintenance management.

## Features
- **Dashboard** — Vehicle health, oil status, fuel analytics, smart alerts
- **Fuel History** — Log fill-ups, track mileage trends, monthly spending
- **Oil Management** — Oil change records, health bar, smart reminders
- **Live RPM Monitor** — Animated tachometer, gear simulation, engine metrics
- **Analytics** — Monthly charts, expense breakdown, AI insights
- **Vehicle Manager** — Multi-vehicle fleet, documents, registration reminders

## Tech Stack
- React 18 + TypeScript
- Recharts (data visualization)
- Framer Motion ready
- CSS custom properties for dark/light theming
- Local state (Firebase-ready architecture)

## Getting Started
```bash
npm install
npm start        # Development server → http://localhost:3000
npm run build    # Production build
```

## Architecture
```
src/
├── App.tsx              # Root + context providers + data models
├── App.css              # Global design system (tokens, components)
├── index.css            # Base reset
├── components/
│   ├── BottomNav.tsx    # Tab navigation
│   └── SplashScreen.tsx # Animated launch screen
└── screens/
    ├── Dashboard.tsx    # Main overview
    ├── FuelHistory.tsx  # Fuel log + charts
    ├── OilChange.tsx    # Oil management
    ├── RPMMeter.tsx     # Live tachometer
    ├── Analytics.tsx    # Reports & insights
    └── Vehicles.tsx     # Fleet management
```

## Firebase Integration (ready to wire)
Replace the in-memory state in `App.tsx` with Firestore collections:
- `vehicles/{userId}/fleet`
- `fuel/{vehicleId}/entries`
- `oil/{vehicleId}/records`

## Mobile Deployment
- **React Native**: Port screens using React Native components (StyleSheet replaces CSS)
- **Capacitor**: `npx cap add android && npx cap add ios` to wrap as native app
- **PWA**: Already works as installable PWA on mobile browsers
